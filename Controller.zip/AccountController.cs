﻿    // ✅ AccountController.cs: Quên mật khẩu & Đặt lại mật khẩu
    using Microsoft.AspNetCore.Identity;
    using Microsoft.AspNetCore.Mvc;
    using DACSN10.Models;
    using System.Threading.Tasks;
    using System.ComponentModel.DataAnnotations;

    namespace DACSN10.Controllers
    {
        public class AccountController : Controller
        {
            private readonly UserManager<User> _userManager;
            private readonly IEmailSender _emailSender;

            public AccountController(UserManager<User> userManager, IEmailSender emailSender)
            {
                _userManager = userManager;
                _emailSender = emailSender;
            }

            public IActionResult ForgotPassword() => View();

            [HttpPost]
            public async Task<IActionResult> ForgotPassword(string email)
            {
                var user = await _userManager.FindByEmailAsync(email);
                if (user == null || !(await _userManager.IsEmailConfirmedAsync(user)))
                    return RedirectToAction("ForgotPasswordConfirmation");

                var token = await _userManager.GeneratePasswordResetTokenAsync(user);
                var callbackUrl = Url.Action("ResetPassword", "Account", new { token, email }, Request.Scheme);

                await _emailSender.SendEmailAsync(email, "Đặt lại mật khẩu",
                    $"Bấm vào <a href='{callbackUrl}'>đây</a> để đặt lại mật khẩu.");

                return RedirectToAction("ForgotPasswordConfirmation");
            }

            public IActionResult ForgotPasswordConfirmation() => View();

            public IActionResult ResetPassword(string token, string email) =>
                View(new ResetPasswordViewModel { Token = token, Email = email });

            [HttpPost]
            public async Task<IActionResult> ResetPassword(ResetPasswordViewModel model)
            {
                if (!ModelState.IsValid) return View(model);

                var user = await _userManager.FindByEmailAsync(model.Email);
                if (user == null) return RedirectToAction("ResetPasswordConfirmation");

                var result = await _userManager.ResetPasswordAsync(user, model.Token, model.Password);
                if (result.Succeeded)
                    return RedirectToAction("ResetPasswordConfirmation");

                foreach (var error in result.Errors)
                    ModelState.AddModelError(string.Empty, error.Description);

                return View(model);
            }

            public IActionResult ResetPasswordConfirmation() => View();
        }

        public class ResetPasswordViewModel
        {
            [Required]
            public string Email { get; set; }

            [Required]
            [DataType(DataType.Password)]
            public string Password { get; set; }

            [Required]
            public string Token { get; set; }
        }

        public interface IEmailSender
        {
            Task SendEmailAsync(string email, string subject, string htmlMessage);
        }

        public class ConsoleEmailSender : IEmailSender
        {
            public Task SendEmailAsync(string email, string subject, string htmlMessage)
            {
            Console.WriteLine($"EMAIL TO: {email} | SUBJECT: {subject}");
            Console.WriteLine(htmlMessage);
                return Task.CompletedTask;
            }
        }
    }