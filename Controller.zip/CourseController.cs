﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using DACSN10.Models;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Linq;
using System;

namespace DACSN10.Controllers
{
    [Authorize]
    public class CourseController : Controller
    {
        private readonly AppDbContext _context;

        public CourseController(AppDbContext context)
        {
            _context = context;
        }

        // 1. View all courses (with pagination)
        [AllowAnonymous]
        public async Task<IActionResult> Index(int page = 1, int pageSize = 12)
        {
            var courses = await _context.Courses
                .AsNoTracking()
                .OrderBy(c => c.TenKhoaHoc)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();
            ViewBag.Page = page;
            ViewBag.PageSize = pageSize;
            ViewBag.TotalCourses = await _context.Courses.CountAsync();
            return View(courses);
        }

        // 2. Popular courses
        [AllowAnonymous]
        public async Task<IActionResult> PopularCourses()
        {
            var courses = await _context.Courses
                .AsNoTracking()
                .Include(c => c.Enrollments)
                .OrderByDescending(c => c.Enrollments.Count)
                .Take(10)
                .ToListAsync();
            return View(courses);
        }

        // 3. New courses
        [AllowAnonymous]
        public async Task<IActionResult> NewCourses()
        {
            var courses = await _context.Courses
                .AsNoTracking()
                .OrderByDescending(c => c.NgayTao)
                .Take(10)
                .ToListAsync();
            return View(courses);
        }

        // 4. Search by name
        [AllowAnonymous]
        public async Task<IActionResult> SearchByName(string keyword)
        {
            if (string.IsNullOrWhiteSpace(keyword))
            {
                TempData["Error"] = "Vui lòng nhập từ khóa tìm kiếm.";
                return View("SearchResult", new List<Course>());
            }
            var result = await _context.Courses
                .AsNoTracking()
                .Where(c => c.TenKhoaHoc.ToLower().Contains(keyword.ToLower()))
                .ToListAsync();
            ViewBag.Keyword = keyword;
            return View("SearchResult", result);
        }

        // 5. Search by topic
        [AllowAnonymous]
        public async Task<IActionResult> SearchByTopic(string topic)
        {
            if (string.IsNullOrWhiteSpace(topic))
            {
                TempData["Error"] = "Vui lòng nhập chủ đề tìm kiếm.";
                return View("SearchResult", new List<Course>());
            }
            var result = await _context.Courses
                .AsNoTracking()
                .Where(c => c.MoTa.ToLower().Contains(topic.ToLower()))
                .ToListAsync();
            ViewBag.Topic = topic;
            return View("SearchResult", result);
        }

        // 6. Search by category
        [AllowAnonymous]
        public async Task<IActionResult> SearchByCategory(int categoryId)
        {
            var result = await _context.CourseCategories
                .AsNoTracking()
                .Include(cc => cc.Course)
                .Where(cc => cc.CategoryID == categoryId)
                .Select(cc => cc.Course)
                .ToListAsync();
            if (!result.Any())
            {
                TempData["Error"] = "Không tìm thấy khóa học trong danh mục này.";
            }
            ViewBag.CategoryId = categoryId;
            return View("SearchResult", result);
        }

        // 7. Course details
        [AllowAnonymous]
        public async Task<IActionResult> Details(int id)
        {
            var course = await _context.Courses
                .AsNoTracking()
                .Include(c => c.User)
                .Include(c => c.Lessons)
                .Include(c => c.CourseCategories).ThenInclude(cc => cc.Category)
                .FirstOrDefaultAsync(c => c.CourseID == id);
            if (course == null)
            {
                TempData["Error"] = "Không tìm thấy khóa học.";
                return NotFound();
            }
            return View(course);
        }

        // 8. Preview video (first lesson)
        [AllowAnonymous]
        public async Task<IActionResult> PreviewVideo(int courseId)
        {
            var lesson = await _context.Lessons
                .AsNoTracking()
                .Where(l => l.CourseID == courseId)
                .OrderBy(l => l.LessonID)
                .FirstOrDefaultAsync();
            if (lesson == null)
            {
                TempData["Error"] = "Không có bài học nào để xem trước.";
                return NotFound();
            }
            return View(lesson);
        }

        // 9. Enroll in a course
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Policy = "UserOnly")]
        public async Task<IActionResult> Enroll(int courseId)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
            {
                TempData["Error"] = "Vui lòng đăng nhập để đăng ký khóa học.";
                return Unauthorized();
            }

            if (!await _context.Courses.AnyAsync(c => c.CourseID == courseId))
            {
                TempData["Error"] = "Không tìm thấy khóa học.";
                return NotFound();
            }

            var exists = await _context.Enrollments.AnyAsync(e => e.UserID == userId && e.CourseID == courseId);
            if (exists)
            {
                TempData["Error"] = "Bạn đã đăng ký khóa học này.";
                return RedirectToAction("MyCourses");
            }

            _context.Enrollments.Add(new Enrollment
            {
                CourseID = courseId,
                UserID = userId,
                EnrollDate = DateTime.Now,
                TrangThai = "Active",
                Progress = 0
            });
            await _context.SaveChangesAsync();

            TempData["Success"] = "Đăng ký khóa học thành công!";
            return RedirectToAction("MyCourses");
        }

        // 10. Add to favorites
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Policy = "UserOnly")]
        public async Task<IActionResult> AddToFavorite(int courseId)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
            {
                TempData["Error"] = "Vui lòng đăng nhập để thêm vào yêu thích.";
                return Unauthorized();
            }

            if (!await _context.Courses.AnyAsync(c => c.CourseID == courseId))
            {
                TempData["Error"] = "Không tìm thấy khóa học.";
                return NotFound();
            }

            var exists = await _context.FavoriteCourses.AnyAsync(f => f.CourseID == courseId && f.UserID == userId);
            if (exists)
            {
                TempData["Error"] = "Khóa học đã có trong danh sách yêu thích.";
                return RedirectToAction("FavoriteCourses");
            }

            _context.FavoriteCourses.Add(new FavoriteCourse
            {
                CourseID = courseId,
                UserID = userId
            });
            await _context.SaveChangesAsync();

            TempData["Success"] = "Đã thêm vào danh sách yêu thích!";
            return RedirectToAction("FavoriteCourses");
        }

        // 11. Remove from favorites
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Policy = "UserOnly")]
        public async Task<IActionResult> RemoveFromFavorite(int courseId)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
            {
                TempData["Error"] = "Vui lòng đăng nhập để xóa khỏi yêu thích.";
                return Unauthorized();
            }

            var fav = await _context.FavoriteCourses
                .FirstOrDefaultAsync(f => f.CourseID == courseId && f.UserID == userId);
            if (fav == null)
            {
                TempData["Error"] = "Khóa học không có trong danh sách yêu thích.";
                return RedirectToAction("FavoriteCourses");
            }

            _context.FavoriteCourses.Remove(fav);
            await _context.SaveChangesAsync();

            TempData["Success"] = "Đã xóa khỏi danh sách yêu thích!";
            return RedirectToAction("FavoriteCourses");
        }

        // 12. View enrolled courses
        public async Task<IActionResult> MyCourses()
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var courses = await _context.Enrollments
                .AsNoTracking()
                .Include(e => e.Course)
                .Where(e => e.UserID == userId && e.TrangThai == "Active")
                .Select(e => e.Course)
                .ToListAsync();
            return View(courses);
        }

        // 13. View course progress
        public async Task<IActionResult> Progress(int courseId)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var enrollment = await _context.Enrollments
                .AsNoTracking()
                .Include(e => e.Course)
                .FirstOrDefaultAsync(e => e.UserID == userId && e.CourseID == courseId);
            if (enrollment == null)
            {
                TempData["Error"] = "Bạn chưa đăng ký khóa học này.";
                return View("EnrollmentNotFound");
            }
            ViewBag.Progress = enrollment.Progress;
            ViewBag.CourseID = courseId;
            ViewBag.CourseName = enrollment.Course.TenKhoaHoc;
            return View();
        }

        // 14. View favorite courses
        public async Task<IActionResult> FavoriteCourses()
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var favs = await _context.FavoriteCourses
                .AsNoTracking()
                .Include(f => f.Course)
                .Where(f => f.UserID == userId)
                .Select(f => f.Course)
                .ToListAsync();
            return View(favs);
        }

        // 15. Get average progress (for progress bar in _Layout.cshtml)
        [HttpGet]
        public async Task<IActionResult> GetAverageProgress()
        {
            if (!User.Identity.IsAuthenticated)
                return Json(0);

            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var averageProgress = await _context.Enrollments
                .Where(e => e.UserID == userId && e.TrangThai == "Active")
                .AverageAsync(e => (float?)e.Progress) ?? 0;

            return Json(averageProgress);
        }
    }
}