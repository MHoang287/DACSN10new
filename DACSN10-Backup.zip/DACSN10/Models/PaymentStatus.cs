﻿namespace DACSN10.Models
{
    public enum PaymentStatus
    {
        Pending = 0,
        Success = 1,
        Failed = 2
    }
}
