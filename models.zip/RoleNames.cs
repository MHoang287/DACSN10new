﻿namespace DACSN10.Models
{
    public static class RoleNames
    {
        public const string Admin = "Admin";
        public const string Teacher = "Teacher";
        public const string User = "User";
    }
}